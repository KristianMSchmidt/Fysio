<div data-role="page" id="XXX_about" data-theme ="a">
 
    <!-- header -->
    <?php include "commons/header_with_back_button.php" ?>
   
    <!-- content -->
    <div role="main" class="ui-content">
        <h2>Om 10-meter-gangtest</h2>

        <h4>Målgruppe</h4>
        <p></p>

        <h4>Tidsforbrug</h4>
        <p></p>

        <h4>Hvad testes</h4>
        <p></p>

        <h5>Relaterede måsleredskaber: </h5>
    </div> <!-- end of content -->

</div> <!-- end of page -->
