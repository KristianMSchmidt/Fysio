<!-- 2,45m up-and-go-test About-->
<div data-role="page" id="upAndGoAbout" data-theme ="a">
        
   <!-- header -->
   <?php include "commons/header_with_back_button.php" ?>
   
    <!-- content -->    
    <div role="main" class="ui-content">
        om up and go...
    </div> <!-- end of content -->
</div>