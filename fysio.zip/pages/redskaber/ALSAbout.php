<!-- ALS About -->
<div data-role="page" id="ALSAbout" data-theme ="a">
        
   <!-- header -->
   <?php include "commons/header_with_back_button.php" ?>
   
    <!-- content -->    
    <div role="main" class="ui-content">
        OM ALS-testen
    </div> <!-- end of content -->
</div>