<!-- 2,45m up-and-go-test -->

<div data-role="page" id="upAndGo" data-theme ="a">
    
    <!-- header -->
    <?php include "commons/header_w_back_to_frontpage.php" ?>

    <!-- content -->
    <div role="main" class="ui-content">
    <h3>2,45m up-and-go-test</h3>
    <p>Beskrivelse</p>
    <a href="#upAndGoAbout" data-role="button" data-icon="arrow-r" data-iconpos="right">Læs om testen</a>

    </div> <!-- end of content -->
</div> <!-- end of page -->
